const ACCENT = "#c8840a";

const T = {
  fr: {
    tagline: "Institut Supérieur des Sciences et Technologies Kouam",
    quickLinks: "LIENS RAPIDES",
    extraLinks: "LIENS EXTRA",
    contactLabel: "CONTACT",
    followUs: "SUIVEZ-NOUS",
    home: "Accueil", programs: "Nos Formations", about: "À Propos",
    scholarships: "Bourses d'Études", contact: "Contacts",
    questions: "Posez vos questions",
    privacy: "Politique de confidentialité",
    terms: "Nos Termes",
    adminLink: "Accès Administrateur",
    rights: "© 2025 ISSTEK. Tous droits réservés.",
    credit: "Redesigné avec React + Firebase",
  },
  en: {
    tagline: "Kouam Higher Institute of Science and Technology",
    quickLinks: "QUICK LINKS",
    extraLinks: "EXTRA LINKS",
    contactLabel: "CONTACT",
    followUs: "FOLLOW US",
    home: "Home", programs: "Programs", about: "About",
    scholarships: "Scholarships", contact: "Contact",
    questions: "Ask Questions",
    privacy: "Privacy Policy",
    terms: "Our Terms",
    adminLink: "Admin Access",
    rights: "© 2025 ISSTEK. All rights reserved.",
    credit: "Redesigned with React + Firebase",
  },
};

export default function Footer({ lang, setPage }) {
  const t = T[lang];

  const socials = [
    { label: "FB", href: "https://www.facebook.com/share/1FePnYb9CA/?mibextid=wwXIfr" },
    { label: "TW", href: "#" },
    { label: "IG", href: "#" },
    { label: "LI", href: "#" },
    { label: "YT", href: "#" },
  ];

  const linkStyle = {
    display: "block", fontSize: "0.82rem", color: "rgba(255,255,255,0.48)",
    textDecoration: "none", marginBottom: "0.5rem", transition: "color 0.2s",
  };

  return (
    <footer style={{ background: "#111", padding: "4.5rem 2.5rem 2rem" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>

        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: "3rem", marginBottom: "3rem" }}>

          {/* Brand */}
          <div>
            <img src="https://isstek.org/images/logo_isstek.JPG" alt="ISSTEK"
              style={{ height: 44, objectFit: "contain", marginBottom: "0.9rem", filter: "brightness(0) invert(1)" }}
              onError={e => e.target.style.display = "none"}
            />
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.1rem", color: "#fff", marginBottom: "0.35rem" }}>
              ISSTEK
            </div>
            <div style={{ fontSize: "0.76rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.7, marginBottom: "1.2rem" }}>
              {t.tagline}
            </div>
            {/* Socials */}
            <div style={{ display: "flex", gap: "0.6rem" }}>
              {socials.map(s => (
                <a key={s.label} href={s.href} target="_blank" rel="noopener noreferrer"
                  style={{
                    width: 32, height: 32, background: "rgba(255,255,255,0.07)", borderRadius: "50%",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: "0.6rem", color: "rgba(255,255,255,0.45)", textDecoration: "none",
                    fontWeight: 700, transition: "background 0.2s",
                  }}
                  onMouseOver={e => e.currentTarget.style.background = ACCENT}
                  onMouseOut={e => e.currentTarget.style.background = "rgba(255,255,255,0.07)"}
                >
                  {s.label}
                </a>
              ))}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <div style={{ fontSize: "0.58rem", color: ACCENT, letterSpacing: "0.16em", fontWeight: 700, marginBottom: "1rem" }}>
              {t.quickLinks}
            </div>
            {[
              { label: t.home, href: "#home" },
              { label: t.programs, href: "#programs" },
              { label: t.about, href: "#about" },
              { label: t.scholarships, href: "#scholarships" },
              { label: t.contact, href: "#contact" },
            ].map(l => (
              <a key={l.label} href={l.href} style={linkStyle}
                onMouseOver={e => e.target.style.color = "#fff"}
                onMouseOut={e => e.target.style.color = "rgba(255,255,255,0.48)"}
              >{l.label}</a>
            ))}
          </div>

          {/* Extra links */}
          <div>
            <div style={{ fontSize: "0.58rem", color: ACCENT, letterSpacing: "0.16em", fontWeight: 700, marginBottom: "1rem" }}>
              {t.extraLinks}
            </div>
            <a href="#" style={linkStyle}
              onMouseOver={e => e.target.style.color = "#fff"} onMouseOut={e => e.target.style.color = "rgba(255,255,255,0.48)"}>
              {t.questions}
            </a>
            <a href="#" style={linkStyle}
              onMouseOver={e => e.target.style.color = "#fff"} onMouseOut={e => e.target.style.color = "rgba(255,255,255,0.48)"}>
              {t.privacy}
            </a>
            <a href="#" style={linkStyle}
              onMouseOver={e => e.target.style.color = "#fff"} onMouseOut={e => e.target.style.color = "rgba(255,255,255,0.48)"}>
              {t.terms}
            </a>
            {/* Admin link */}
            <a href="/admin"
              onClick={e => { e.preventDefault(); setPage("admin"); window.history.pushState({}, "", "/admin"); }}
              style={{ ...linkStyle, color: ACCENT }}
              onMouseOver={e => e.target.style.color = "#f5c35a"}
              onMouseOut={e => e.target.style.color = ACCENT}
            >
              🔐 {t.adminLink}
            </a>
          </div>

          {/* Contact info */}
          <div>
            <div style={{ fontSize: "0.58rem", color: ACCENT, letterSpacing: "0.16em", fontWeight: 700, marginBottom: "1rem" }}>
              {t.contactLabel}
            </div>
            {["+237 677 699 402", "+237 698 942 412", "+237 698 942 412", "isstek@gmail.com", "Yaoundé, Cameroun"].map(l => (
              <div key={l} style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.45)", marginBottom: "0.45rem" }}>{l}</div>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div style={{
          borderTop: "1px solid rgba(255,255,255,0.07)", paddingTop: "1.5rem",
          display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: "0.5rem",
        }}>
          <span style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.28)" }}>{t.rights}</span>
          <span style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.2)" }}>
            Créé par WICOM AGENCY · {t.credit}
          </span>
        </div>
      </div>
    </footer>
  );
}
