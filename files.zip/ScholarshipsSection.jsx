const ACCENT = "#c8840a";

const T = {
  fr: {
    label: "BOURSES D'ÉTUDES",
    title: "Jusqu'à 50%\nde Réduction.",
    body: "Des bourses d'études disponibles couvrant jusqu'à 50% des frais de scolarité. Ne laissez pas les finances être un obstacle à votre avenir professionnel.",
    cta: "SOUSCRIRE MAINTENANT",
    badge: "BOURSE",
  },
  en: {
    label: "SCHOLARSHIPS",
    title: "Up to 50%\nReduction.",
    body: "Scholarships available covering up to 50% of tuition fees. Don't let finances be an obstacle to your professional future.",
    cta: "APPLY NOW",
    badge: "GRANT",
  },
};

const GRID_IMGS = [
  "https://isstek.org/images/diplomation5.jpeg",
  "https://isstek.org/images/diplomation9.jpeg",
  "https://isstek.org/images/diplomation13.jpeg",
  "https://isstek.org/images/labo_sante1.jpeg",
];

export default function ScholarshipsSection({ lang }) {
  const t = T[lang];

  return (
    <section id="scholarships" style={{ padding: "7rem 2.5rem", background: "#fff8ee" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "center" }}>

        {/* Image grid */}
        <div style={{ position: "relative" }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.8rem" }}>
            {GRID_IMGS.map(img => (
              <img
                key={img} src={img} alt="ISSTEK students"
                style={{ width: "100%", aspectRatio: "4/3", objectFit: "cover", borderRadius: 4, display: "block" }}
                onError={e => e.target.style.display = "none"}
              />
            ))}
          </div>
          {/* Center badge */}
          <div style={{
            position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
            background: ACCENT, color: "#fff", borderRadius: "50%",
            width: 88, height: 88,
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
            fontFamily: "'Playfair Display', serif", fontSize: "1.55rem", fontWeight: 700, lineHeight: 1,
            boxShadow: "0 8px 32px rgba(200,132,10,0.45)",
          }}>
            50%
            <span style={{ fontSize: "0.52rem", fontFamily: "'Outfit', sans-serif", letterSpacing: "0.08em", marginTop: "0.15rem" }}>
              {t.badge}
            </span>
          </div>
        </div>

        {/* Text */}
        <div>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 5vw, 4rem)", color: "#1a1a1a", lineHeight: 1.08, marginBottom: "1.5rem", whiteSpace: "pre-line" }}>
            {t.title}
          </h2>
          <p style={{ fontSize: "1.02rem", color: "#4a4a4a", lineHeight: 1.82, marginBottom: "2rem" }}>
            {t.body}
          </p>
          <a href="#contact" style={{
            display: "inline-block", background: ACCENT, color: "#fff",
            fontWeight: 700, fontSize: "0.78rem", padding: "0.9rem 2.2rem",
            textDecoration: "none", letterSpacing: "0.1em", borderRadius: 3,
          }}>
            {t.cta}
          </a>
        </div>

      </div>
    </section>
  );
}
