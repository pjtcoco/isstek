import { useState, useEffect } from "react";
import NavBar from "./components/NavBar.jsx";
import HeroSection from "./components/HeroSection.jsx";
import AboutSection from "./components/AboutSection.jsx";
import ProgramsSection from "./components/ProgramsSection.jsx";
import PartnersSection from "./components/PartnersSection.jsx";
import ScholarshipsSection from "./components/ScholarshipsSection.jsx";
import OpenDoorsSection from "./components/OpenDoorsSection.jsx";
import StaffSection from "./components/StaffSection.jsx";
import ContactSection from "./components/ContactSection.jsx";
import Footer from "./components/Footer.jsx";
import AdminPanel from "./pages/AdminPanel.jsx";

export default function App() {
  const [lang, setLang] = useState("fr");
  const [page, setPage] = useState("home");

  useEffect(() => {
    if (window.location.pathname === "/admin") setPage("admin");
  }, []);

  if (page === "admin") return <AdminPanel />;

  return (
    <div style={{ fontFamily: "'Outfit', sans-serif", background: "#fafaf8", color: "#1a1a1a" }}>
      <NavBar lang={lang} setLang={setLang} />
      <HeroSection lang={lang} />
      <AboutSection lang={lang} />
      <ProgramsSection lang={lang} />
      <PartnersSection lang={lang} />
      <ScholarshipsSection lang={lang} />
      <OpenDoorsSection lang={lang} />
      <StaffSection lang={lang} />
      <ContactSection lang={lang} />
      <Footer lang={lang} setPage={setPage} />
    </div>
  );
}
