import { useState } from "react";

const ACCENT = "#c8840a";

const T = {
  fr: {
    label: "STAFF ADMINISTRATIF",
    title: "Mot de\nNos Dirigeants.",
    readMore: "Voir Plus",
    readLess: "Réduire",
    staff: [
      {
        name: "Mme. KOUAM",
        role: "PROMOTRICE — Fondatrice de plusieurs écoles",
        img: "https://isstek.org/images/promotice.jpeg",
        short: "L'Institut Supérieur ISSTEK a été créé dans l'optique d'apporter des solutions aux problèmes du choix des filières de formation.",
        full: "Chers Parents, Chers Jeunes étudiants et aspirants au magistère du savoir, du savoir-être et du savoir-faire, La construction et la réalisation de vos objectifs de vie passe pour la plupart des cas par la qualité du travail, la rigueur, l'endurance et la patience. L'Institut Supérieur ISSTEK a été créé justement dans l'optique d'apporter des solutions aux problèmes du choix des filières de formation et du suivi des carrières professionnelles des étudiants. ISSTEK prépare et assure la réussite et le succès des jeunes en réduisant drastiquement le chômage au Cameroun.",
      },
      {
        name: "M. KOUAM Etienne",
        role: "PDG — PLEG HORS ÉCHELLE retraité",
        img: "https://isstek.org/images/pdg.jpeg",
        short: "ISSTEK prépare et assure la réussite et le succès des jeunes en réduisant drastiquement le chômage au Cameroun.",
        full: "Chers Parents, Chers Jeunes étudiants et aspirants au magistère du savoir, du savoir-être et du savoir-faire, De par son offre diversifiée de filières professionnalisantes, la qualité de son personnel enseignant et administratif et la pléthore de ses partenaires sociaux constitués de plusieurs entreprises nationales et même étrangères, ISSTEK prépare et assure la réussite et le succès des jeunes en réduisant drastiquement le chômage au Cameroun. Chers Parents, saisissez cette occasion en inscrivant votre enfant à l'ISSTEK et assurez son avenir professionnel.",
      },
      {
        name: "M. BINAM Alphonse Donatien",
        role: "DAAC — Enseignant Chercheur en Droit et Science Politique",
        img: "https://isstek.org/images/binam.jpeg",
        short: "ISSTEK forme ses étudiants dans les filières les plus sollicitées dans le marché de l'emploi avec un bon maillage de la théorie et de la pratique.",
        full: "Chers Jeunes étudiants et aspirants aux études Universitaires, L'institut Supérieur des Sciences et Technologies KOUAM (ISSTEK) est un établissement d'enseignement supérieur qui à peine de naissance, se positionne déjà parmi les meilleurs établissements de la capitale politique du Cameroun. ISSTEK présente des atouts majeurs tels qu'un somptueux campus moderne, des ateliers et laboratoires à la pointe de la technologie, une dynamique équipe d'enseignants et de personnels administratifs, et des partenaires nationaux et internationaux de renom.",
      },
    ],
  },
  en: {
    label: "ADMINISTRATIVE STAFF",
    title: "A Word From\nOur Leaders.",
    readMore: "Read More",
    readLess: "Collapse",
    staff: [
      {
        name: "Mrs. KOUAM",
        role: "FOUNDER & DIRECTOR",
        img: "https://isstek.org/images/promotice.jpeg",
        short: "ISSTEK Higher Institute was created to provide solutions to the challenges of choosing training programs and following students' professional careers.",
        full: "Dear Parents, Dear Students and aspiring scholars, The achievement of your life goals depends primarily on the quality of work, discipline, endurance and patience. ISSTEK Higher Institute was created precisely to provide solutions to the problems of choosing training programs and monitoring students' professional careers. ISSTEK prepares and ensures the success of young people by drastically reducing unemployment in Cameroon.",
      },
      {
        name: "Mr. KOUAM Etienne",
        role: "CEO — Retired Senior Teacher",
        img: "https://isstek.org/images/pdg.jpeg",
        short: "ISSTEK prepares and ensures the success of young people by drastically reducing unemployment in Cameroon.",
        full: "Dear Parents, Dear Students, Through its diverse range of professional programs, the quality of its teaching and administrative staff, and the wealth of its social partners — both national and international companies — ISSTEK prepares and ensures the success of young people by drastically reducing unemployment in Cameroon. Parents, seize this opportunity by enrolling your child at ISSTEK and securing their professional future.",
      },
      {
        name: "Mr. BINAM Alphonse Donatien",
        role: "DAAC — Law & Political Science Researcher",
        img: "https://isstek.org/images/binam.jpeg",
        short: "ISSTEK trains students in the most sought-after fields in the job market with a strong blend of theory and practice.",
        full: "Dear Students and university aspirants, ISSTEK Higher Institute of Science and Technology is an establishment that, barely born, already positions itself among the best institutions in Cameroon's political capital. ISSTEK offers a magnificent modern campus, state-of-the-art workshops and laboratories, a dynamic team of teachers and administrative staff, and prestigious national and international partners.",
      },
    ],
  },
};

export default function StaffSection({ lang }) {
  const t = T[lang];
  const [expanded, setExpanded] = useState(null);

  return (
    <section id="staff" style={{ padding: "7rem 2.5rem", background: "#1a1a1a" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>

        <div style={{ textAlign: "center", marginBottom: "3.5rem" }}>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 5vw, 4rem)", color: "#fff", lineHeight: 1.08, whiteSpace: "pre-line" }}>
            {t.title}
          </h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "2rem" }}>
          {t.staff.map((person, i) => (
            <div
              key={i}
              style={{
                background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 6, overflow: "hidden", transition: "border-color 0.25s",
              }}
              onMouseOver={e => e.currentTarget.style.borderColor = "rgba(200,132,10,0.4)"}
              onMouseOut={e => e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)"}
            >
              <img
                src={person.img} alt={person.name}
                style={{ width: "100%", aspectRatio: "4/3", objectFit: "cover", objectPosition: "top", display: "block" }}
                onError={e => e.target.style.display = "none"}
              />
              <div style={{ padding: "1.5rem" }}>
                <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.1em", fontWeight: 700, marginBottom: "0.3rem" }}>
                  {person.role}
                </div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.18rem", color: "#fff", marginBottom: "0.9rem" }}>
                  {person.name}
                </h3>
                <p style={{ fontSize: "0.82rem", color: "rgba(255,255,255,0.52)", lineHeight: 1.72 }}>
                  {expanded === i ? person.full : person.short}
                </p>
                <button
                  onClick={() => setExpanded(expanded === i ? null : i)}
                  style={{
                    background: "none", border: "none", color: ACCENT,
                    fontSize: "0.74rem", fontWeight: 700, letterSpacing: "0.06em",
                    cursor: "pointer", marginTop: "0.85rem", padding: 0,
                    fontFamily: "'Outfit', sans-serif",
                  }}
                >
                  {expanded === i ? `▴ ${t.readLess}` : `▾ ${t.readMore}`}
                </button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
