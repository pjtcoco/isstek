const ACCENT = "#c8840a";

const T = {
  fr: {
    label: "JOURNÉES PORTES OUVERTES",
    title: "Venez Nous\nDécouvrir.",
    body: "Les Journées Portes Ouvertes de l'ISSTEK sont destinées à vous présenter nos différents cursus, permettre de mieux nous connaître et de poser vos questions. Nos équipes pédagogiques seront ravies de vous accompagner.",
    cta: "EN SAVOIR PLUS",
  },
  en: {
    label: "OPEN DAYS",
    title: "Come\nDiscover Us.",
    body: "ISSTEK Open Days are designed to present our various programs, let you get to know us better and answer all your questions. Our teaching teams will be delighted to guide you.",
    cta: "LEARN MORE",
  },
};

const GALLERY = [
  "https://isstek.org/images/labo_info.jpeg",
  "https://isstek.org/images/labo_gmh2.jpeg",
  "https://isstek.org/images/diplomation5.jpeg",
  "https://isstek.org/images/labo_sante1.jpeg",
];

export default function OpenDoorsSection({ lang }) {
  const t = T[lang];

  return (
    <section id="opendays" style={{ padding: "7rem 2.5rem", background: "#fafaf8" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1.3fr", gap: "5rem", alignItems: "center" }}>

        {/* Text */}
        <div>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 5vw, 4rem)", color: "#1a1a1a", lineHeight: 1.08, marginBottom: "1.5rem", whiteSpace: "pre-line" }}>
            {t.title}
          </h2>
          <p style={{ fontSize: "1rem", color: "#4a4a4a", lineHeight: 1.82, marginBottom: "2rem" }}>
            {t.body}
          </p>
          <a href="#contact" style={{
            display: "inline-block", background: "transparent", color: ACCENT,
            fontWeight: 700, fontSize: "0.78rem", padding: "0.85rem 2rem",
            textDecoration: "none", letterSpacing: "0.1em",
            border: `2px solid ${ACCENT}`, borderRadius: 3, transition: "all 0.22s",
          }}
            onMouseOver={e => { e.currentTarget.style.background = ACCENT; e.currentTarget.style.color = "#fff"; }}
            onMouseOut={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = ACCENT; }}>
            {t.cta}
          </a>
        </div>

        {/* Gallery grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "0.85rem" }}>
          {GALLERY.map((img, i) => (
            <img
              key={i} src={img} alt="ISSTEK campus"
              style={{
                width: "100%", aspectRatio: "4/3", objectFit: "cover",
                borderRadius: 4, display: "block", transition: "transform 0.32s",
                cursor: "default",
              }}
              onMouseOver={e => e.target.style.transform = "scale(1.04)"}
              onMouseOut={e => e.target.style.transform = "scale(1)"}
              onError={e => e.target.style.display = "none"}
            />
          ))}
        </div>

      </div>
    </section>
  );
}
