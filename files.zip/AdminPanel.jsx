import { useState } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCTION: Replace mock functions below with real Firebase calls:
//
//   import { auth, db } from "../firebase.js";
//   import { signInWithEmailAndPassword, signOut } from "firebase/auth";
//   import { collection, addDoc, getDocs, deleteDoc, doc, updateDoc } from "firebase/firestore";
//
// Then replace mockSignIn/mockSignOut with:
//   const signIn = (email, pw) => signInWithEmailAndPassword(auth, email, pw);
//   const logout = () => signOut(auth);
// ─────────────────────────────────────────────────────────────────────────────

const ACCENT = "#c8840a";

// ── Mock auth (demo mode — replace with Firebase in production) ───────────────
const mockSignIn = async (email, password) => {
  if (email === "admin@isstek.org" && password === "isstek2025") return true;
  throw new Error(email && password ? "Identifiants incorrects." : "Renseignez vos identifiants.");
};

// ── Shared style helpers ──────────────────────────────────────────────────────
const card = {
  background: "#fff", border: "1px solid #eee",
  borderRadius: 6, padding: "1.5rem", boxShadow: "0 2px 14px rgba(0,0,0,0.06)",
};

const inp = {
  width: "100%", border: "1px solid #ddd", padding: "0.75rem 1rem",
  fontFamily: "'Outfit', sans-serif", fontSize: "0.9rem", color: "#1a1a1a",
  borderRadius: 3, outline: "none", boxSizing: "border-box", background: "#fafaf8",
};

const lbl = {
  fontSize: "0.58rem", color: "#888", letterSpacing: "0.12em",
  fontWeight: 700, display: "block", marginBottom: "0.35rem",
};

const primaryBtn = {
  background: ACCENT, color: "#fff", border: "none",
  padding: "0.65rem 1.4rem", fontFamily: "'Outfit', sans-serif",
  fontWeight: 700, fontSize: "0.76rem", letterSpacing: "0.07em",
  cursor: "pointer", borderRadius: 3,
};

const ghostBtn = {
  background: "transparent", color: ACCENT, border: `1px solid ${ACCENT}`,
  padding: "0.55rem 1rem", fontFamily: "'Outfit', sans-serif",
  fontWeight: 700, fontSize: "0.72rem", letterSpacing: "0.06em",
  cursor: "pointer", borderRadius: 3,
};

const dangerBtn = {
  background: "#dc2626", color: "#fff", border: "none",
  padding: "0.45rem 0.85rem", fontFamily: "'Outfit', sans-serif",
  fontWeight: 700, fontSize: "0.68rem", cursor: "pointer", borderRadius: 3,
};

// ── Login screen ──────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handle = async () => {
    setLoading(true); setError("");
    try {
      await mockSignIn(email, password);
      onLogin();
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  return (
    <>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,700;1,600&display=swap'); *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }`}</style>
      <div style={{ minHeight: "100vh", background: "#1a1a1a", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Outfit', sans-serif" }}>
        <div style={{ ...card, width: 380, padding: "2.5rem" }}>
          <div style={{ textAlign: "center", marginBottom: "2rem" }}>
            <img src="https://isstek.org/images/logo_isstek.JPG" alt="ISSTEK"
              style={{ height: 50, objectFit: "contain", marginBottom: "0.9rem" }}
              onError={e => e.target.style.display = "none"} />
            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.5rem", color: "#1a1a1a" }}>Administration</h1>
            <p style={{ fontSize: "0.76rem", color: "#888", marginTop: "0.25rem" }}>Panneau de gestion ISSTEK</p>
          </div>

          <div style={{ display: "grid", gap: "0.9rem" }}>
            <div>
              <label style={lbl}>EMAIL</label>
              <input type="email" placeholder="admin@isstek.org" value={email}
                onChange={e => setEmail(e.target.value)} style={inp}
                onFocus={e => e.target.style.borderColor = ACCENT}
                onBlur={e => e.target.style.borderColor = "#ddd"} />
            </div>
            <div>
              <label style={lbl}>MOT DE PASSE</label>
              <input type="password" placeholder="••••••••" value={password}
                onChange={e => setPassword(e.target.value)} style={inp}
                onKeyDown={e => e.key === "Enter" && handle()}
                onFocus={e => e.target.style.borderColor = ACCENT}
                onBlur={e => e.target.style.borderColor = "#ddd"} />
            </div>

            {error && (
              <div style={{ fontSize: "0.78rem", color: "#dc2626", padding: "0.5rem 0.8rem", background: "#fef2f2", borderRadius: 3 }}>
                {error}
              </div>
            )}

            <button onClick={handle} disabled={loading}
              style={{ ...primaryBtn, padding: "0.9rem", opacity: loading ? 0.65 : 1, marginTop: "0.3rem" }}>
              {loading ? "CONNEXION..." : "SE CONNECTER →"}
            </button>

            <p style={{ fontSize: "0.68rem", color: "#bbb", textAlign: "center", marginTop: "0.3rem" }}>
              Démo : admin@isstek.org / isstek2025
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Dashboard tab ─────────────────────────────────────────────────────────────
function Dashboard({ news, photos, enrollments }) {
  const stats = [
    { label: "Total inscriptions", value: enrollments.length, color: ACCENT },
    { label: "En attente", value: enrollments.filter(e => e.status === "En attente").length, color: "#f59e0b" },
    { label: "Confirmées", value: enrollments.filter(e => e.status === "Confirmé").length, color: "#10b981" },
    { label: "Articles publiés", value: news.filter(n => n.published).length, color: "#2c2c7a" },
  ];

  return (
    <div>
      <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", marginBottom: "2rem" }}>Tableau de bord</h2>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: "1.2rem", marginBottom: "2.5rem" }}>
        {stats.map(s => (
          <div key={s.label} style={{ ...card, borderTop: `3px solid ${s.color}` }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "2.4rem", color: s.color, lineHeight: 1 }}>{s.value}</div>
            <div style={{ fontSize: "0.74rem", color: "#888", marginTop: "0.4rem" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Recent rows */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.5rem" }}>
        <div style={card}>
          <h3 style={{ fontSize: "0.95rem", fontWeight: 700, marginBottom: "1rem", color: "#1a1a1a" }}>Dernières inscriptions</h3>
          {enrollments.slice(0, 4).map(e => (
            <div key={e.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "0.6rem 0", borderBottom: "1px solid #f2f2f2" }}>
              <div>
                <div style={{ fontSize: "0.85rem", fontWeight: 600 }}>{e.name}</div>
                <div style={{ fontSize: "0.7rem", color: "#888" }}>{e.program}</div>
              </div>
              <span style={{
                fontSize: "0.62rem", padding: "0.18rem 0.55rem", borderRadius: 2, fontWeight: 700,
                background: e.status === "Confirmé" ? "#d1fae5" : "#fef3c7",
                color: e.status === "Confirmé" ? "#065f46" : "#92400e",
              }}>{e.status}</span>
            </div>
          ))}
        </div>

        <div style={card}>
          <h3 style={{ fontSize: "0.95rem", fontWeight: 700, marginBottom: "1rem", color: "#1a1a1a" }}>Dernières actualités</h3>
          {news.slice(0, 4).map(n => (
            <div key={n.id} style={{ padding: "0.6rem 0", borderBottom: "1px solid #f2f2f2" }}>
              <div style={{ fontSize: "0.85rem", fontWeight: 600 }}>{n.title}</div>
              <div style={{ fontSize: "0.7rem", color: "#888" }}>{n.date}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── News tab ──────────────────────────────────────────────────────────────────
function NewsTab({ news, setNews }) {
  const [form, setForm] = useState({ title: "", body: "" });

  const publish = () => {
    if (!form.title || !form.body) return;
    setNews([{
      id: Date.now(), title: form.title, body: form.body,
      date: new Date().toISOString().split("T")[0], published: true,
    }, ...news]);
    setForm({ title: "", body: "" });
  };

  const toggle = (id) => setNews(news.map(n => n.id === id ? { ...n, published: !n.published } : n));
  const remove = (id) => setNews(news.filter(n => n.id !== id));

  return (
    <div>
      <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", marginBottom: "2rem" }}>Gestion des Actualités</h2>

      {/* New article form */}
      <div style={{ ...card, marginBottom: "2rem" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "1.2rem" }}>Nouvel article</h3>
        <div style={{ display: "grid", gap: "0.85rem" }}>
          <div>
            <label style={lbl}>TITRE</label>
            <input placeholder="Titre de l'article" value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })} style={inp}
              onFocus={e => e.target.style.borderColor = ACCENT} onBlur={e => e.target.style.borderColor = "#ddd"} />
          </div>
          <div>
            <label style={lbl}>CONTENU</label>
            <textarea placeholder="Contenu de l'article..." value={form.body} rows={4}
              onChange={e => setForm({ ...form, body: e.target.value })}
              style={{ ...inp, resize: "vertical" }}
              onFocus={e => e.target.style.borderColor = ACCENT} onBlur={e => e.target.style.borderColor = "#ddd"} />
          </div>
          <button onClick={publish} style={{ ...primaryBtn, width: "fit-content" }}>PUBLIER L'ARTICLE</button>
        </div>
      </div>

      {/* Articles list */}
      <div style={{ display: "grid", gap: "1rem" }}>
        {news.map(n => (
          <div key={n.id} style={{ ...card, display: "flex", gap: "1.5rem", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: "0.7rem", marginBottom: "0.3rem" }}>
                <span style={{ fontWeight: 700, fontSize: "0.95rem" }}>{n.title}</span>
                <span style={{
                  fontSize: "0.6rem", padding: "0.15rem 0.5rem", borderRadius: 2, fontWeight: 700,
                  background: n.published ? "#d1fae5" : "#f3f4f6", color: n.published ? "#065f46" : "#888",
                }}>
                  {n.published ? "Publié" : "Brouillon"}
                </span>
              </div>
              <div style={{ fontSize: "0.7rem", color: "#aaa", marginBottom: "0.4rem" }}>{n.date}</div>
              <p style={{ fontSize: "0.82rem", color: "#666" }}>{n.body}</p>
            </div>
            <div style={{ display: "flex", gap: "0.5rem", flexShrink: 0 }}>
              <button onClick={() => toggle(n.id)} style={ghostBtn}>
                {n.published ? "Dépublier" : "Publier"}
              </button>
              <button onClick={() => remove(n.id)} style={dangerBtn}>✕</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Photos tab ────────────────────────────────────────────────────────────────
function PhotosTab({ photos, setPhotos }) {
  const [form, setForm] = useState({ url: "", caption: "", category: "Campus" });
  const categories = ["Campus", "Événements", "Diplômations", "Laboratoires", "Étudiants"];

  const add = () => {
    if (!form.url || !form.caption) return;
    setPhotos([{ id: Date.now(), ...form }, ...photos]);
    setForm({ url: "", caption: "", category: "Campus" });
  };

  return (
    <div>
      <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", marginBottom: "2rem" }}>Galerie Photos</h2>

      {/* Add photo form */}
      <div style={{ ...card, marginBottom: "2rem" }}>
        <h3 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "1.2rem" }}>Ajouter une photo</h3>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
          <div>
            <label style={lbl}>URL DE L'IMAGE</label>
            <input placeholder="https://exemple.com/image.jpg" value={form.url}
              onChange={e => setForm({ ...form, url: e.target.value })} style={inp}
              onFocus={e => e.target.style.borderColor = ACCENT} onBlur={e => e.target.style.borderColor = "#ddd"} />
          </div>
          <div>
            <label style={lbl}>LÉGENDE</label>
            <input placeholder="Description de la photo" value={form.caption}
              onChange={e => setForm({ ...form, caption: e.target.value })} style={inp}
              onFocus={e => e.target.style.borderColor = ACCENT} onBlur={e => e.target.style.borderColor = "#ddd"} />
          </div>
          <div>
            <label style={lbl}>CATÉGORIE</label>
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} style={inp}>
              {categories.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div style={{ display: "flex", alignItems: "flex-end" }}>
            <button onClick={add} style={{ ...primaryBtn, width: "100%", padding: "0.78rem" }}>
              AJOUTER LA PHOTO
            </button>
          </div>
        </div>
        <p style={{ fontSize: "0.7rem", color: "#aaa", marginTop: "0.9rem" }}>
          💡 En production avec Firebase Storage activé, vous pourrez uploader des fichiers directement depuis votre ordinateur.
        </p>
      </div>

      {/* Photo grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(210px, 1fr))", gap: "1rem" }}>
        {photos.map(p => (
          <div key={p.id} style={{ ...card, padding: 0, overflow: "hidden" }}>
            <img src={p.url} alt={p.caption}
              style={{ width: "100%", aspectRatio: "4/3", objectFit: "cover", display: "block" }}
              onError={e => { e.target.style.background = "#eee"; e.target.style.minHeight = "140px"; }} />
            <div style={{ padding: "0.8rem" }}>
              <div style={{ fontSize: "0.8rem", fontWeight: 600, marginBottom: "0.3rem", color: "#1a1a1a" }}>{p.caption}</div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: "0.62rem", color: ACCENT, background: "#fff8ee", padding: "0.15rem 0.5rem", borderRadius: 2 }}>
                  {p.category}
                </span>
                <button onClick={() => setPhotos(photos.filter(x => x.id !== p.id))}
                  style={{ background: "none", border: "none", color: "#dc2626", cursor: "pointer", fontSize: "0.8rem" }}>✕</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Enrollments tab ───────────────────────────────────────────────────────────
function EnrollmentsTab({ enrollments, setEnrollments }) {
  const confirm = (id) => setEnrollments(enrollments.map(e => e.id === id ? { ...e, status: e.status === "Confirmé" ? "En attente" : "Confirmé" } : e));
  const remove = (id) => setEnrollments(enrollments.filter(e => e.id !== id));

  return (
    <div>
      <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", marginBottom: "2rem" }}>Gestion des Inscriptions</h2>
      <div style={card}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: "2px solid #f0f0f0" }}>
              {["Nom", "Email", "Formation", "Date", "Statut", "Actions"].map(h => (
                <th key={h} style={{ textAlign: "left", padding: "0.6rem 0.8rem", fontSize: "0.58rem", color: "#888", letterSpacing: "0.12em", fontWeight: 700 }}>
                  {h.toUpperCase()}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {enrollments.map(e => (
              <tr key={e.id} style={{ borderBottom: "1px solid #f7f7f7" }}>
                <td style={{ padding: "0.8rem", fontSize: "0.85rem", fontWeight: 600 }}>{e.name}</td>
                <td style={{ padding: "0.8rem", fontSize: "0.8rem", color: "#666" }}>{e.email}</td>
                <td style={{ padding: "0.8rem", fontSize: "0.8rem" }}>{e.program}</td>
                <td style={{ padding: "0.8rem", fontSize: "0.74rem", color: "#888" }}>{e.date}</td>
                <td style={{ padding: "0.8rem" }}>
                  <span style={{
                    fontSize: "0.62rem", padding: "0.2rem 0.6rem", borderRadius: 2, fontWeight: 700,
                    background: e.status === "Confirmé" ? "#d1fae5" : "#fef3c7",
                    color: e.status === "Confirmé" ? "#065f46" : "#92400e",
                  }}>{e.status}</span>
                </td>
                <td style={{ padding: "0.8rem" }}>
                  <div style={{ display: "flex", gap: "0.4rem" }}>
                    <button onClick={() => confirm(e.id)} style={{ ...ghostBtn, fontSize: "0.65rem", padding: "0.35rem 0.7rem" }}>
                      {e.status === "Confirmé" ? "Annuler" : "Confirmer"}
                    </button>
                    <button onClick={() => remove(e.id)} style={{ ...dangerBtn, fontSize: "0.65rem", padding: "0.35rem 0.65rem" }}>✕</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ── Settings tab ──────────────────────────────────────────────────────────────
function SettingsTab() {
  return (
    <div>
      <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", marginBottom: "2rem" }}>Paramètres & Accès</h2>
      <div style={{ display: "grid", gap: "1.5rem" }}>

        <div style={card}>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "0.9rem" }}>👥 Ajouter un administrateur</h3>
          <p style={{ fontSize: "0.85rem", color: "#555", lineHeight: 1.75, marginBottom: "1rem" }}>
            Pour donner l'accès à un collaborateur (pour ajouter des photos, publier des actualités ou gérer les inscriptions) :
          </p>
          <div style={{ background: "#f8f8f6", padding: "1rem 1.2rem", borderRadius: 4, fontSize: "0.82rem", color: "#444", lineHeight: 1.9 }}>
            <strong>Étapes :</strong><br />
            1. Aller sur <a href="https://console.firebase.google.com" target="_blank" rel="noopener noreferrer" style={{ color: ACCENT }}>console.firebase.google.com</a><br />
            2. Sélectionner le projet <strong>isstek-website</strong><br />
            3. Authentication → Users → <strong>Add User</strong><br />
            4. Entrer l'email et le mot de passe de la personne<br />
            5. Envoyer à la personne : <strong>isstek.org/admin</strong> + ses identifiants ✅
          </div>
        </div>

        <div style={card}>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "0.9rem" }}>🌐 Domaine (isstek.org)</h3>
          <div style={{ background: "#f8f8f6", padding: "1rem 1.2rem", borderRadius: 4, fontSize: "0.82rem", color: "#444", lineHeight: 1.9 }}>
            <strong>Option A — Firebase Hosting (gratuit, recommandé) :</strong><br />
            1. Dans le terminal : <code style={{ background: "#eee", padding: "0.1rem 0.4rem", borderRadius: 2 }}>npm run build</code> puis <code style={{ background: "#eee", padding: "0.1rem 0.4rem", borderRadius: 2 }}>firebase deploy</code><br />
            2. Firebase Console → Hosting → <strong>Add custom domain</strong><br />
            3. Entrez <strong>isstek.org</strong> et copiez les enregistrements DNS fournis<br />
            4. Ajoutez ces DNS chez votre registraire de domaine → attendre 24–48h ✅<br /><br />
            <strong>Option B — Garder votre hébergeur actuel :</strong><br />
            1. <code style={{ background: "#eee", padding: "0.1rem 0.4rem", borderRadius: 2 }}>npm run build</code> → uploader le dossier <strong>/dist</strong> via FTP<br />
            2. Le domaine isstek.org reste inchangé ✅
          </div>
        </div>

        <div style={card}>
          <h3 style={{ fontSize: "1rem", fontWeight: 700, marginBottom: "0.9rem" }}>⚙️ Connexion Firebase réelle</h3>
          <p style={{ fontSize: "0.85rem", color: "#555", lineHeight: 1.75 }}>
            Ouvrez le fichier <code style={{ background: "#f0f0f0", padding: "0.1rem 0.4rem", borderRadius: 2 }}>src/firebase.js</code> et remplacez les valeurs <code>REPLACE_WITH_YOUR_...</code> par vos vraies clés Firebase pour activer la sauvegarde dans le cloud des inscriptions, articles et photos.
          </p>
        </div>

      </div>
    </div>
  );
}

// ── Main Admin Panel ──────────────────────────────────────────────────────────
export default function AdminPanel() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [tab, setTab] = useState("dashboard");

  const [news, setNews] = useState([
    { id: 1, title: "Journées Portes Ouvertes 2025", date: "2025-03-15", body: "Venez découvrir nos formations lors de nos journées portes ouvertes. Nos équipes vous attendent.", published: true },
    { id: 2, title: "Résultats BTS Session 2024", date: "2025-01-10", body: "Félicitations à tous les lauréats de la session 2024 !", published: true },
    { id: 3, title: "Ouverture des inscriptions 2025-2026", date: "2024-12-01", body: "Les inscriptions pour l'année académique 2025-2026 sont officiellement ouvertes.", published: true },
  ]);

  const [photos, setPhotos] = useState([
    { id: 1, url: "https://isstek.org/images/labo_info.jpeg", caption: "Laboratoire Informatique", category: "Laboratoires" },
    { id: 2, url: "https://isstek.org/images/diplomation5.jpeg", caption: "Cérémonie de diplomation", category: "Diplômations" },
    { id: 3, url: "https://isstek.org/images/labo_sante1.jpeg", caption: "Laboratoire Santé", category: "Laboratoires" },
    { id: 4, url: "https://isstek.org/images/labo_gmh2.jpeg", caption: "Atelier Génie Mécanique", category: "Campus" },
  ]);

  const [enrollments, setEnrollments] = useState([
    { id: 1, name: "Marie Ngono", email: "m.ngono@email.com", program: "BTS Commerce", date: "2025-05-28", status: "En attente" },
    { id: 2, name: "Jean-Claude Mbarga", email: "jc.mbarga@email.com", program: "Licence Pro Informatique", date: "2025-05-25", status: "Confirmé" },
    { id: 3, name: "Aissatou Diallo", email: "a.diallo@email.com", program: "Master Pro Management", date: "2025-05-20", status: "Confirmé" },
    { id: 4, name: "Patrick Nkomo", email: "p.nkomo@email.com", program: "BTS Industriel", date: "2025-05-18", status: "En attente" },
  ]);

  if (!loggedIn) return <LoginScreen onLogin={() => setLoggedIn(true)} />;

  const tabs = [
    { id: "dashboard", label: "📊 Tableau de bord" },
    { id: "news",      label: "📰 Actualités" },
    { id: "photos",    label: "🖼️  Galerie" },
    { id: "enrollments", label: "📋 Inscriptions" },
    { id: "settings",  label: "⚙️  Paramètres" },
  ];

  return (
    <>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,700;1,600&display=swap'); *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; } body { font-family: 'Outfit', sans-serif; }`}</style>
      <div style={{ minHeight: "100vh", background: "#f5f5f3", fontFamily: "'Outfit', sans-serif" }}>

        {/* Top bar */}
        <div style={{ background: "#1a1a1a", padding: "0 2rem", height: 56, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.8rem" }}>
            <img src="https://isstek.org/images/logo_isstek.JPG" alt="ISSTEK"
              style={{ height: 30, filter: "brightness(0) invert(1)", objectFit: "contain" }}
              onError={e => e.target.style.display = "none"} />
            <span style={{ color: ACCENT, fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", fontWeight: 700 }}>ISSTEK</span>
            <span style={{ color: "rgba(255,255,255,0.3)", fontSize: "0.7rem" }}>Administration</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
            <span style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.76rem" }}>admin@isstek.org</span>
            <button onClick={() => setLoggedIn(false)} style={{ ...ghostBtn, fontSize: "0.68rem", padding: "0.35rem 0.75rem" }}>
              DÉCONNEXION
            </button>
          </div>
        </div>

        <div style={{ display: "flex", minHeight: "calc(100vh - 56px)" }}>
          {/* Sidebar */}
          <div style={{ width: 224, background: "#fff", borderRight: "1px solid #eee", padding: "1.5rem 0", flexShrink: 0 }}>
            {tabs.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                display: "block", width: "100%", textAlign: "left",
                background: tab === t.id ? "#fff8ee" : "transparent", border: "none",
                borderLeft: tab === t.id ? `3px solid ${ACCENT}` : "3px solid transparent",
                padding: "0.78rem 1.5rem", fontFamily: "'Outfit', sans-serif",
                fontSize: "0.82rem", color: tab === t.id ? ACCENT : "#555",
                cursor: "pointer", fontWeight: tab === t.id ? 700 : 400, transition: "all 0.15s",
              }}>
                {t.label}
              </button>
            ))}

            <div style={{ margin: "2rem 1.2rem 0", padding: "1rem", background: "#f7f7f5", borderRadius: 4 }}>
              <div style={{ fontSize: "0.58rem", color: "#aaa", letterSpacing: "0.1em", marginBottom: "0.5rem" }}>SITE PUBLIC</div>
              <a href="/" style={{ fontSize: "0.78rem", color: ACCENT, textDecoration: "none", fontWeight: 700 }}>
                ← Voir le site
              </a>
            </div>
          </div>

          {/* Main content */}
          <div style={{ flex: 1, padding: "2.5rem", overflowY: "auto" }}>
            {tab === "dashboard"   && <Dashboard news={news} photos={photos} enrollments={enrollments} />}
            {tab === "news"        && <NewsTab news={news} setNews={setNews} />}
            {tab === "photos"      && <PhotosTab photos={photos} setPhotos={setPhotos} />}
            {tab === "enrollments" && <EnrollmentsTab enrollments={enrollments} setEnrollments={setEnrollments} />}
            {tab === "settings"    && <SettingsTab />}
          </div>
        </div>
      </div>
    </>
  );
}
