import { useState } from "react";

const ACCENT = "#c8840a";

const T = {
  fr: {
    label: "CYCLES DE FORMATIONS",
    title: "Choisissez\nVotre Parcours.",
    learnMore: "En savoir plus →",
    programs: [
      {
        code: "BTS / HND",
        color: "#c8840a",
        img: "https://isstek.org/images/diplome.jpeg",
        duration: "2 ans",
        title: "Brevet de Technicien Supérieur",
        desc: "Après 2 ans de formations, l'étudiant obtient le BTS dans divers domaines et est capable de faire valoir ses compétences dans une entreprise.",
        tracks: ["Commerce & Gestion", "Industriel", "Santé"],
      },
      {
        code: "LICENCE / BACHELOR",
        color: "#1a5c3a",
        img: "https://isstek.org/images/labo_info3.jpeg",
        duration: "3 ans",
        title: "Licence Professionnelle",
        desc: "La licence professionnelle permet une forte immersion dans l'entreprise grâce à des stages, séminaires animés par des cadres et consultants internationaux.",
        tracks: ["Informatique", "Gestion", "Commerce International"],
      },
      {
        code: "MASTER PRO / DEGREE",
        color: "#2c2c7a",
        img: "https://isstek.org/images/diplomation6.jpeg",
        duration: "5 ans",
        title: "Master Professionnel",
        desc: "Le programme offre aux étudiants de deuxième cycle la possibilité de définir un parcours personnalisé parmi une diversité d'enseignements.",
        tracks: ["Management", "Ingénierie", "Recherche"],
      },
    ],
  },
  en: {
    label: "TRAINING PROGRAMS",
    title: "Choose Your\nPath.",
    learnMore: "Learn more →",
    programs: [
      {
        code: "BTS / HND",
        color: "#c8840a",
        img: "https://isstek.org/images/diplome.jpeg",
        duration: "2 years",
        title: "Higher Technician Certificate",
        desc: "After 2 years of training, students obtain the BTS in various fields and can demonstrate their skills in a company.",
        tracks: ["Commerce & Management", "Industrial", "Health"],
      },
      {
        code: "DEGREE / BACHELOR",
        color: "#1a5c3a",
        img: "https://isstek.org/images/labo_info3.jpeg",
        duration: "3 years",
        title: "Professional Degree",
        desc: "ISSTEK's professional degree enables deep business immersion through internships and seminars led by international executives and consultants.",
        tracks: ["Computer Science", "Management", "International Trade"],
      },
      {
        code: "MASTER PRO / DEGREE",
        color: "#2c2c7a",
        img: "https://isstek.org/images/diplomation6.jpeg",
        duration: "5 years",
        title: "Professional Master",
        desc: "The program gives second-cycle students the opportunity to define a personalized pathway among the diverse courses available.",
        tracks: ["Management", "Engineering", "Research"],
      },
    ],
  },
};

export default function ProgramsSection({ lang }) {
  const t = T[lang];
  const [hovered, setHovered] = useState(null);

  return (
    <section id="programs" style={{ padding: "7rem 2.5rem", background: "#fafaf8" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>

        <div style={{ textAlign: "center", marginBottom: "3.5rem" }}>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 5vw, 4rem)", color: "#1a1a1a", lineHeight: 1.08, whiteSpace: "pre-line" }}>
            {t.title}
          </h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "1.5rem" }}>
          {t.programs.map((prog, i) => (
            <div
              key={i}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
              style={{
                background: "#fff", borderRadius: 6, overflow: "hidden",
                boxShadow: hovered === i
                  ? `0 0 0 3px ${prog.color}, 0 16px 48px rgba(0,0,0,0.13)`
                  : "0 2px 18px rgba(0,0,0,0.07)",
                transition: "all 0.3s",
                transform: hovered === i ? "translateY(-4px)" : "translateY(0)",
              }}
            >
              {/* Image */}
              <div style={{ position: "relative", overflow: "hidden" }}>
                <img
                  src={prog.img} alt={prog.title}
                  style={{ width: "100%", aspectRatio: "4/3", objectFit: "cover", display: "block", transition: "transform 0.45s" }}
                  onMouseOver={e => e.target.style.transform = "scale(1.06)"}
                  onMouseOut={e => e.target.style.transform = "scale(1)"}
                  onError={e => e.target.style.display = "none"}
                />
                <div style={{
                  position: "absolute", top: "1rem", left: "1rem",
                  background: prog.color, color: "#fff",
                  padding: "0.28rem 0.75rem", fontSize: "0.62rem", fontWeight: 700, letterSpacing: "0.1em", borderRadius: 2,
                }}>
                  {prog.code}
                </div>
                <div style={{
                  position: "absolute", bottom: "0.8rem", right: "0.8rem",
                  background: "rgba(0,0,0,0.58)", color: "#fff",
                  padding: "0.2rem 0.6rem", fontSize: "0.6rem", letterSpacing: "0.08em", borderRadius: 2,
                }}>
                  {prog.duration}
                </div>
              </div>

              {/* Content */}
              <div style={{ padding: "1.5rem" }}>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.22rem", color: "#1a1a1a", marginBottom: "0.75rem" }}>
                  {prog.title}
                </h3>
                <p style={{ fontSize: "0.83rem", color: "#666", lineHeight: 1.72, marginBottom: "1rem" }}>
                  {prog.desc}
                </p>

                {/* Track chips */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: "0.45rem", marginBottom: "1.2rem" }}>
                  {prog.tracks.map(track => (
                    <span key={track} style={{
                      background: `${prog.color}18`, color: prog.color,
                      border: `1px solid ${prog.color}40`,
                      padding: "0.18rem 0.55rem", fontSize: "0.66rem", fontWeight: 600, borderRadius: 2,
                    }}>
                      {track}
                    </span>
                  ))}
                </div>

                <a href="#contact" style={{
                  color: prog.color, fontSize: "0.78rem", fontWeight: 700,
                  textDecoration: "none", letterSpacing: "0.04em",
                }}>
                  {t.learnMore}
                </a>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
