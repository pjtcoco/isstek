const ACCENT = "#c8840a";

const T = {
  fr: {
    badge: "INSCRIPTIONS OUVERTES",
    line1: "L'INSTITUT",
    line2: "DE L'EXCELLENCE",
    sub: "Institut Supérieur des Sciences et Technologies Kouam — Yaoundé, Cameroun",
    motto: "Travail · Connaissance · Succès",
    cta1: "S'INSCRIRE MAINTENANT",
    cta2: "DÉCOUVRIR NOS FORMATIONS",
    stats: [
      ["BTS / HND", "2 ans de formation"],
      ["Licence / Bachelor", "Immersion entreprise"],
      ["Master Pro", "Recherche & Excellence"],
      ["50%", "Bourses disponibles"],
    ],
  },
  en: {
    badge: "ENROLLMENT OPEN",
    line1: "THE INSTITUTE",
    line2: "OF EXCELLENCE",
    sub: "Kouam Higher Institute of Science and Technology — Yaoundé, Cameroon",
    motto: "Work · Knowledge · Success",
    cta1: "ENROLL NOW",
    cta2: "EXPLORE PROGRAMS",
    stats: [
      ["BTS / HND", "2-year training"],
      ["Degree / Bachelor", "Business immersion"],
      ["Master Pro", "Research & Excellence"],
      ["50%", "Scholarships available"],
    ],
  },
};

export default function HeroSection({ lang }) {
  const t = T[lang];

  return (
    <section id="home" style={{ position: "relative", minHeight: "92vh", overflow: "hidden", display: "flex", alignItems: "center" }}>

      {/* Background image */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "url('https://isstek.org/images/isstek1.jpg')",
        backgroundSize: "cover", backgroundPosition: "center",
        filter: "brightness(0.32)",
      }} />

      {/* Warm gradient overlay */}
      <div style={{
        position: "absolute", inset: 0,
        background: "linear-gradient(135deg, rgba(20,12,2,0.88) 0%, rgba(170,90,5,0.28) 100%)",
      }} />

      {/* Dot pattern */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: "radial-gradient(circle, rgba(200,132,10,0.09) 1px, transparent 1px)",
        backgroundSize: "42px 42px",
      }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: 1280, margin: "0 auto", padding: "0 2.5rem", width: "100%" }}>

        {/* Live badge */}
        <div style={{
          display: "inline-flex", alignItems: "center", gap: "0.5rem",
          background: "rgba(200,132,10,0.18)", border: "1px solid rgba(200,132,10,0.55)",
          padding: "0.3rem 1rem", marginBottom: "2rem", borderRadius: 2,
        }}>
          <span style={{
            width: 7, height: 7, borderRadius: "50%", background: "#f5c35a",
            display: "inline-block", animation: "blink 2s infinite",
          }} />
          <span style={{ color: "#f5c35a", fontSize: "0.65rem", letterSpacing: "0.2em", fontWeight: 700 }}>
            {t.badge}
          </span>
        </div>

        {/* Headline */}
        <h1 style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "clamp(3.2rem, 8vw, 7.5rem)",
          lineHeight: 1, color: "#fff", marginBottom: "1.5rem", letterSpacing: "-0.01em",
        }}>
          {t.line1}<br />
          <span style={{ color: ACCENT, fontStyle: "italic" }}>{t.line2}</span>
        </h1>

        <p style={{ fontSize: "1.05rem", color: "rgba(255,255,255,0.72)", maxWidth: 520, lineHeight: 1.7, marginBottom: "0.8rem" }}>
          {t.sub}
        </p>
        <p style={{ fontSize: "0.88rem", color: ACCENT, letterSpacing: "0.14em", fontWeight: 700, marginBottom: "2.5rem" }}>
          {t.motto}
        </p>

        {/* CTAs */}
        <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap", marginBottom: "4rem" }}>
          <a href="#contact" style={{
            background: ACCENT, color: "#fff", fontWeight: 700, fontSize: "0.78rem",
            padding: "0.9rem 2rem", textDecoration: "none", letterSpacing: "0.1em",
            borderRadius: 3, border: `2px solid ${ACCENT}`, transition: "all 0.2s",
          }}
            onMouseOver={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#f5c35a"; }}
            onMouseOut={e => { e.currentTarget.style.background = ACCENT; e.currentTarget.style.color = "#fff"; }}>
            {t.cta1}
          </a>
          <a href="#programs" style={{
            background: "transparent", color: "rgba(255,255,255,0.82)", fontWeight: 600,
            fontSize: "0.78rem", padding: "0.9rem 2rem", textDecoration: "none",
            letterSpacing: "0.1em", border: "2px solid rgba(255,255,255,0.3)", borderRadius: 3, transition: "all 0.2s",
          }}
            onMouseOver={e => { e.currentTarget.style.borderColor = "#f5c35a"; e.currentTarget.style.color = "#f5c35a"; }}
            onMouseOut={e => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.3)"; e.currentTarget.style.color = "rgba(255,255,255,0.82)"; }}>
            {t.cta2}
          </a>
        </div>

        {/* Stats bar */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: "0", borderTop: "1px solid rgba(255,255,255,0.12)" }}>
          {t.stats.map(([val, label], i) => (
            <div key={i} style={{
              padding: "1.4rem 2.5rem 1rem 0", marginRight: "2.5rem",
              borderRight: i < t.stats.length - 1 ? "1px solid rgba(255,255,255,0.12)" : "none",
            }}>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.7rem", color: "#f5c35a", lineHeight: 1 }}>{val}</div>
              <div style={{ fontSize: "0.68rem", color: "rgba(255,255,255,0.52)", letterSpacing: "0.07em", marginTop: "0.3rem" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      <style>{`@keyframes blink { 0%,100%{opacity:1;} 50%{opacity:0.25;} }`}</style>
    </section>
  );
}
