import { useState } from "react";

const ACCENT = "#c8840a";

const T = {
  fr: {
    label: "NOUS CONTACTER",
    title: "Parlons de\nVotre Avenir.",
    phones: ["677 699 402 / 699 101 557", "698 942 412 / 676 343 066"],
    email: "isstek@gmail.com",
    address: "Yaoundé-Etoug-Ebé, Face Collège de l'Espérance",
    hours: "Lundi – Vendredi : 07h30 – 18h00\nSamedi : 08h00 – 14h00",
    hoursLabel: "HORAIRES D'ACCUEIL",
    fName: "NOM COMPLET", fNamePh: "Votre nom complet",
    fEmail: "ADRESSE EMAIL", fEmailPh: "votre@email.com",
    fMsg: "MESSAGE", fMsgPh: "Comment pouvons-nous vous aider ?",
    fSubmit: "ENVOYER LE MESSAGE →",
    fSending: "ENVOI EN COURS...",
    successTitle: "MESSAGE ENVOYÉ !",
    successSub: "Nous vous répondrons dans les 48 heures.",
    errorMsg: "Erreur lors de l'envoi. Écrivez directement à isstek@gmail.com",
    required: "Champ requis",
    invalidEmail: "Email invalide",
  },
  en: {
    label: "CONTACT US",
    title: "Let's Talk\nAbout Your Future.",
    phones: ["677 699 402 / 699 101 557", "698 942 412 / 676 343 066"],
    email: "isstek@gmail.com",
    address: "Yaoundé-Etoug-Ebé, Opposite Collège de l'Espérance",
    hours: "Monday – Friday: 7:30am – 6:00pm\nSaturday: 8:00am – 2:00pm",
    hoursLabel: "OFFICE HOURS",
    fName: "FULL NAME", fNamePh: "Your full name",
    fEmail: "EMAIL ADDRESS", fEmailPh: "your@email.com",
    fMsg: "MESSAGE", fMsgPh: "How can we help you?",
    fSubmit: "SEND MESSAGE →",
    fSending: "SENDING...",
    successTitle: "MESSAGE SENT!",
    successSub: "We will reply within 48 hours.",
    errorMsg: "Send failed. Please write directly to isstek@gmail.com",
    required: "Required",
    invalidEmail: "Invalid email",
  },
};

export default function ContactSection({ lang }) {
  const t = T[lang];
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | loading | success | error

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = t.required;
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) e.email = t.invalidEmail;
    if (!form.message.trim()) e.message = t.required;
    return e;
  };

  const handleSubmit = async () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    setErrors({});
    setStatus("loading");
    try {
      // In production: import { db } from "../firebase" and use addDoc
      // const { addDoc, collection } = await import("firebase/firestore");
      // await addDoc(collection(db, "messages"), { ...form, timestamp: new Date(), lang });
      await new Promise(r => setTimeout(r, 900)); // Demo delay
      setStatus("success");
      setForm({ name: "", email: "", message: "" });
    } catch {
      setStatus("error");
    }
  };

  const inp = {
    width: "100%", background: "#fafaf8", border: "1px solid #ddd",
    padding: "0.82rem 1rem", fontFamily: "'Outfit', sans-serif",
    fontSize: "0.9rem", color: "#1a1a1a", outline: "none",
    borderRadius: 3, boxSizing: "border-box", transition: "border-color 0.2s",
  };
  const lbl = {
    fontSize: "0.58rem", color: "#888", letterSpacing: "0.12em",
    fontWeight: 700, display: "block", marginBottom: "0.35rem",
  };
  const errStyle = { fontSize: "0.62rem", color: "#dc2626", marginTop: "0.28rem" };

  return (
    <section id="contact" style={{ padding: "7rem 2.5rem", background: "#fff" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem" }}>

        {/* Info panel */}
        <div>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 5vw, 4rem)", color: "#1a1a1a", lineHeight: 1.08, marginBottom: "2rem", whiteSpace: "pre-line" }}>
            {t.title}
          </h2>

          <div style={{ display: "grid", gap: "1.2rem", marginBottom: "2rem" }}>
            {[
              { icon: "📞", text: t.phones[0] },
              { icon: "📞", text: t.phones[1] },
              { icon: "✉️", text: t.email },
              { icon: "📍", text: t.address },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: "0.8rem" }}>
                <span style={{ fontSize: "1.1rem" }}>{item.icon}</span>
                <span style={{ fontSize: "0.9rem", color: "#4a4a4a", lineHeight: 1.55 }}>{item.text}</span>
              </div>
            ))}
          </div>

          <div style={{ padding: "1.2rem 1.4rem", background: "#fff8ee", borderRadius: 4, border: `1px solid rgba(200,132,10,0.2)` }}>
            <div style={{ fontSize: "0.58rem", color: ACCENT, fontWeight: 700, letterSpacing: "0.12em", marginBottom: "0.5rem" }}>
              {t.hoursLabel}
            </div>
            <div style={{ fontSize: "0.84rem", color: "#555", lineHeight: 1.8, whiteSpace: "pre-line" }}>{t.hours}</div>
          </div>
        </div>

        {/* Form */}
        <div>
          {status === "success" ? (
            <div style={{ padding: "3rem", textAlign: "center", background: "#f0faf5", border: "1px solid rgba(26,92,58,0.3)", borderRadius: 6 }}>
              <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>✅</div>
              <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.6rem", color: "#1a5c3a", marginBottom: "0.5rem" }}>
                {t.successTitle}
              </div>
              <p style={{ color: "#555", fontSize: "0.9rem" }}>{t.successSub}</p>
            </div>
          ) : (
            <div style={{ display: "grid", gap: "1rem" }}>

              {/* Name */}
              <div>
                <label style={lbl}>{t.fName}</label>
                <input type="text" placeholder={t.fNamePh} value={form.name}
                  onChange={e => setForm({ ...form, name: e.target.value })}
                  style={{ ...inp, borderColor: errors.name ? "#dc2626" : "#ddd" }}
                  onFocus={e => e.target.style.borderColor = ACCENT}
                  onBlur={e => e.target.style.borderColor = errors.name ? "#dc2626" : "#ddd"}
                />
                {errors.name && <div style={errStyle}>{errors.name}</div>}
              </div>

              {/* Email */}
              <div>
                <label style={lbl}>{t.fEmail}</label>
                <input type="email" placeholder={t.fEmailPh} value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  style={{ ...inp, borderColor: errors.email ? "#dc2626" : "#ddd" }}
                  onFocus={e => e.target.style.borderColor = ACCENT}
                  onBlur={e => e.target.style.borderColor = errors.email ? "#dc2626" : "#ddd"}
                />
                {errors.email && <div style={errStyle}>{errors.email}</div>}
              </div>

              {/* Message */}
              <div>
                <label style={lbl}>{t.fMsg}</label>
                <textarea placeholder={t.fMsgPh} value={form.message} rows={5}
                  onChange={e => setForm({ ...form, message: e.target.value })}
                  style={{ ...inp, resize: "vertical", borderColor: errors.message ? "#dc2626" : "#ddd" }}
                  onFocus={e => e.target.style.borderColor = ACCENT}
                  onBlur={e => e.target.style.borderColor = errors.message ? "#dc2626" : "#ddd"}
                />
                {errors.message && <div style={errStyle}>{errors.message}</div>}
              </div>

              {/* Submit */}
              <button onClick={handleSubmit} disabled={status === "loading"}
                style={{
                  background: ACCENT, color: "#fff", border: "none", padding: "1rem",
                  fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: "0.8rem",
                  letterSpacing: "0.1em", cursor: status === "loading" ? "not-allowed" : "pointer",
                  borderRadius: 3, opacity: status === "loading" ? 0.65 : 1, transition: "opacity 0.2s",
                }}
                onMouseOver={e => { if (status !== "loading") e.target.style.opacity = "0.85"; }}
                onMouseOut={e => e.target.style.opacity = status === "loading" ? "0.65" : "1"}
              >
                {status === "loading" ? t.fSending : t.fSubmit}
              </button>

              {status === "error" && (
                <div style={{ fontSize: "0.76rem", color: "#dc2626", padding: "0.6rem", background: "#fef2f2", borderRadius: 3 }}>
                  {t.errorMsg}
                </div>
              )}
            </div>
          )}
        </div>

      </div>
    </section>
  );
}
