const ACCENT = "#c8840a";

const T = {
  fr: {
    label: "À PROPOS DE NOUS",
    title: "Qui sommes-nous ?",
    body: "Une école experte dans les domaines du commerce, des sciences et des technologies disposant d'un campus High Tech. Notre école rassemble une équipe de professionnels en matière de formation d'une part, et d'autre part d'entrepreneurs issus du monde de l'entreprise et qui gardent un pied dans la gestion d'entreprise.",
    decree: "Arrêté No 20-08759/N/MINESUP/SG/DDES/ESUP/SDA/GA du 19/08/2020",
    decreeLabel: "DÉCRET OFFICIEL",
    location: "Yaoundé-Etoug-Ebé, Face Collège de l'Espérance",
    cta: "CE QUE NOUS VOUS PROPOSONS",
    founded: "FONDÉ",
  },
  en: {
    label: "ABOUT US",
    title: "Who Are We?",
    body: "An expert school in commerce, science and technology with a High Tech campus. Our school brings together a team of training professionals and entrepreneurs from the business world who maintain a foothold in business management.",
    decree: "Decree No 20-08759/N/MINESUP/SG/DDES/ESUP/SDA/GA of 19/08/2020",
    decreeLabel: "OFFICIAL DECREE",
    location: "Yaoundé-Etoug-Ebé, Opposite Collège de l'Espérance",
    cta: "WHAT WE OFFER",
    founded: "FOUNDED",
  },
};

export default function AboutSection({ lang }) {
  const t = T[lang];

  return (
    <section id="about" style={{ padding: "7rem 2.5rem", background: "#fff" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "5rem", alignItems: "center" }}>

        {/* Text */}
        <div>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2.4rem, 5vw, 4rem)", color: "#1a1a1a", lineHeight: 1.08, marginBottom: "1.8rem" }}>
            {t.title}
          </h2>
          <p style={{ fontSize: "1rem", color: "#4a4a4a", lineHeight: 1.85, marginBottom: "1.6rem" }}>
            {t.body}
          </p>

          {/* Decree box */}
          <div style={{ padding: "0.9rem 1.2rem", background: "#fff8ee", borderLeft: `4px solid ${ACCENT}`, marginBottom: "1.5rem" }}>
            <div style={{ fontSize: "0.6rem", color: ACCENT, fontWeight: 700, letterSpacing: "0.1em", marginBottom: "0.3rem" }}>{t.decreeLabel}</div>
            <div style={{ fontSize: "0.78rem", color: "#555", lineHeight: 1.5 }}>{t.decree}</div>
          </div>

          {/* Location */}
          <div style={{ display: "flex", alignItems: "center", gap: "0.6rem", color: "#666", fontSize: "0.85rem", marginBottom: "2rem" }}>
            <span>📍</span> {t.location}
          </div>

          <a href="#programs" style={{
            display: "inline-block", background: ACCENT, color: "#fff",
            fontWeight: 700, fontSize: "0.75rem", padding: "0.85rem 2rem",
            textDecoration: "none", letterSpacing: "0.1em", borderRadius: 3,
          }}>
            {t.cta}
          </a>
        </div>

        {/* Image */}
        <div style={{ position: "relative" }}>
          <img
            src="https://isstek.org/images/isstek1.jpg"
            alt="Campus ISSTEK"
            style={{ width: "100%", aspectRatio: "4/3", objectFit: "cover", borderRadius: 4, boxShadow: "0 24px 60px rgba(0,0,0,0.14)", display: "block" }}
            onError={e => e.target.style.display = "none"}
          />
          {/* Year badge */}
          <div style={{
            position: "absolute", bottom: "-1.5rem", left: "-1.5rem",
            background: ACCENT, color: "#fff", padding: "1.3rem 1.5rem",
            borderRadius: 3, boxShadow: "0 8px 28px rgba(200,132,10,0.35)",
          }}>
            <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.9rem", fontWeight: 700, lineHeight: 1 }}>2020</div>
            <div style={{ fontSize: "0.6rem", letterSpacing: "0.1em", fontWeight: 700, marginTop: "0.2rem" }}>{t.founded}</div>
          </div>
        </div>

      </div>
    </section>
  );
}
