import { useState, useEffect } from "react";

const T = {
  fr: {
    home: "Accueil", programs: "Nos Formations", about: "À Propos",
    scholarships: "Bourses", openDoors: "Portes Ouvertes", contact: "Contacts",
    enroll: "S'inscrire",
    bts: "BTS", hnd: "HND",
    btsComm: "Commerce & Gestion", btsInd: "Industriel", btsSante: "Santé",
    licence: "Licence Pro", bachelor: "Bachelor Degree",
    masterPro: "Master Pro", masterDeg: "Master Degree",
  },
  en: {
    home: "Home", programs: "Programs", about: "About",
    scholarships: "Scholarships", openDoors: "Open Days", contact: "Contact",
    enroll: "Enroll",
    bts: "BTS", hnd: "HND",
    btsComm: "Commerce & Management", btsInd: "Industrial", btsSante: "Health",
    licence: "Professional Degree", bachelor: "Bachelor Degree",
    masterPro: "Professional Master", masterDeg: "Master Degree",
  },
};

const ACCENT = "#c8840a";

export default function NavBar({ lang, setLang }) {
  const t = T[lang];
  const [scrolled, setScrolled] = useState(false);
  const [dropOpen, setDropOpen] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const dropItems = [
    { label: `${t.bts} — ${t.btsComm}` }, { label: `${t.bts} — ${t.btsInd}` },
    { label: `${t.bts} — ${t.btsSante}` }, { label: t.hnd },
    { label: t.licence }, { label: t.bachelor },
    { label: t.masterPro }, { label: t.masterDeg },
  ];

  const navLinks = [
    { label: t.home, href: "#home" },
    { label: t.about, href: "#about" },
    { label: t.scholarships, href: "#scholarships" },
    { label: t.openDoors, href: "#opendays" },
    { label: t.contact, href: "#contact" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Playfair+Display:ital,wght@0,700;0,800;1,600&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { font-family: 'Outfit', sans-serif; }
        .nl { color: #2a2a2a; text-decoration: none; font-size: 0.82rem; font-weight: 500; letter-spacing: 0.03em; transition: color 0.2s; }
        .nl:hover { color: ${ACCENT}; }
        .di { display: block; padding: 0.65rem 1.3rem; font-size: 0.78rem; color: #333; text-decoration: none; transition: background 0.15s, color 0.15s; font-family: 'Outfit', sans-serif; }
        .di:hover { background: #fff8ee; color: ${ACCENT}; }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-thumb { background: ${ACCENT}; border-radius: 3px; }
      `}</style>

      <nav style={{
        position: "sticky", top: 0, zIndex: 900,
        background: scrolled ? "rgba(250,250,248,0.97)" : "#fafaf8",
        backdropFilter: scrolled ? "blur(16px)" : "none",
        borderBottom: `1px solid rgba(200,132,10,${scrolled ? "0.18" : "0.08"})`,
        transition: "all 0.3s",
      }}>
        <div style={{ maxWidth: 1280, margin: "0 auto", padding: "0 2rem", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>

          {/* Logo */}
          <a href="#home" style={{ display: "flex", alignItems: "center", gap: "0.7rem", textDecoration: "none" }}>
            <img src="https://isstek.org/images/logo_isstek.JPG" alt="ISSTEK logo"
              style={{ height: 38, objectFit: "contain" }}
              onError={e => { e.target.style.display = "none"; }} />
            <div>
              <div style={{ fontWeight: 800, fontSize: "1.1rem", color: "#1a1a1a", letterSpacing: "0.06em" }}>ISSTEK</div>
              <div style={{ fontSize: "0.5rem", color: ACCENT, letterSpacing: "0.1em", fontWeight: 700 }}>YAOUNDÉ · CAMEROUN</div>
            </div>
          </a>

          {/* Links */}
          <div style={{ display: "flex", alignItems: "center", gap: "1.6rem" }}>

            {/* Programs dropdown */}
            <div style={{ position: "relative" }}
              onMouseEnter={() => setDropOpen(true)}
              onMouseLeave={() => setDropOpen(false)}>
              <span className="nl" style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: "0.25rem" }}>
                {t.programs} <span style={{ fontSize: "0.55rem", marginTop: 1 }}>▾</span>
              </span>
              {dropOpen && (
                <div style={{
                  position: "absolute", top: "100%", left: 0,
                  background: "#fff", border: "1px solid rgba(200,132,10,0.2)",
                  boxShadow: "0 10px 36px rgba(0,0,0,0.1)",
                  minWidth: 230, paddingTop: "0.4rem", paddingBottom: "0.4rem",
                }}>
                  {dropItems.map(d => (
                    <a key={d.label} href="#programs" className="di">{d.label}</a>
                  ))}
                </div>
              )}
            </div>

            {navLinks.map(l => (
              <a key={l.label} href={l.href} className="nl">{l.label}</a>
            ))}

            {/* Language toggle */}
            <button onClick={() => setLang(lang === "fr" ? "en" : "fr")}
              style={{
                background: "#fff8ee", border: `1px solid ${ACCENT}`, color: ACCENT,
                fontFamily: "'Outfit', sans-serif", fontWeight: 700, fontSize: "0.68rem",
                padding: "0.28rem 0.65rem", cursor: "pointer", letterSpacing: "0.08em", borderRadius: 3,
              }}>
              {lang === "fr" ? "EN" : "FR"}
            </button>

            {/* CTA button */}
            <a href="#contact"
              style={{
                background: ACCENT, color: "#fff", fontWeight: 700, fontSize: "0.72rem",
                padding: "0.55rem 1.2rem", textDecoration: "none", letterSpacing: "0.08em",
                borderRadius: 3, transition: "opacity 0.2s",
              }}
              onMouseOver={e => e.currentTarget.style.opacity = "0.85"}
              onMouseOut={e => e.currentTarget.style.opacity = "1"}>
              {t.enroll}
            </a>
          </div>
        </div>
      </nav>
    </>
  );
}
