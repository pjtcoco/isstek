const ACCENT = "#c8840a";

const T = {
  fr: { label: "NOS PARTENAIRES & TUTELLES", title: "Reconnus\nMondialement." },
  en: { label: "OUR PARTNERS & AFFILIATES", title: "Globally\nRecognized." },
};

const PARTNERS = [
  { name: "UIT de Bandjoun",            img: "https://isstek.org/images/IUT_Banjoun.PNG" },
  { name: "Ontario Technologies",        img: "https://isstek.org/images/ontario_tech.PNG" },
  { name: "UCLouvain",                   img: "https://isstek.org/images/UCL.PNG" },
  { name: "Univ. Libre de Bruxelles",    img: "https://isstek.org/images/ULB.PNG" },
  { name: "Univ. de Ngaoundéré",         img: "https://isstek.org/images/univ_ngaoundere.jpg" },
  { name: "Univ. de Dschang",            img: "https://isstek.org/images/univ_dschang.png" },
];

export default function PartnersSection({ lang }) {
  const t = T[lang];

  return (
    <section id="partners" style={{ padding: "6rem 2.5rem", background: "#1a1a1a" }}>
      <div style={{ maxWidth: 1280, margin: "0 auto" }}>

        <div style={{ textAlign: "center", marginBottom: "3rem" }}>
          <div style={{ fontSize: "0.6rem", color: ACCENT, letterSpacing: "0.22em", fontWeight: 700, marginBottom: "0.5rem" }}>
            — {t.label}
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: "clamp(2rem, 4vw, 3.2rem)", color: "#fff", lineHeight: 1.1, whiteSpace: "pre-line" }}>
            {t.title}
          </h2>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: "1.5rem" }}>
          {PARTNERS.map(p => (
            <div
              key={p.name}
              style={{
                background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.09)",
                padding: "1.6rem", display: "flex", flexDirection: "column",
                alignItems: "center", gap: "0.8rem", borderRadius: 4, transition: "all 0.25s",
                cursor: "default",
              }}
              onMouseOver={e => { e.currentTarget.style.background = "rgba(200,132,10,0.1)"; e.currentTarget.style.borderColor = "rgba(200,132,10,0.35)"; }}
              onMouseOut={e => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.09)"; }}
            >
              <img
                src={p.img} alt={p.name}
                style={{ height: 52, objectFit: "contain", filter: "brightness(0) invert(1)", opacity: 0.82 }}
                onError={e => { e.target.style.display = "none"; }}
              />
              <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.52)", textAlign: "center", fontWeight: 500 }}>
                {p.name}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
